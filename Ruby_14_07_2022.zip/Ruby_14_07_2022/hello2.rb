module Geek
def geeks
	puts 'this is Geek module'
end
end
