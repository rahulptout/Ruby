@wordArray = []
   print "Enter a String :  "
   content = "A paragraph is a series of sentences that are organized and coherent, and are all related to a single topic. Almost every piece of writing you do that is longer than a few sentences should be organized into paragraphs. This is because paragraphs show a reader where the subdivisions of an essay begin and end, and thus help the reader see the organization of the essay and grasp its main points."
	# content = gets.chomp.to_s
	content =content.downcase 
	content = content.gsub(/[,.;]/,"")
	@wordArray = content.split
	 # puts @wordArray

   
h = {}
count = 0
for i in @wordArray do
	# puts "#{i}"
	for j in @wordArray do
		if i==j
			# puts "#{j}"
		  	count+=1
		end

	end
	


end 	

@h.each do | key, value|
  puts "#{key}: $#{value}"
end	





