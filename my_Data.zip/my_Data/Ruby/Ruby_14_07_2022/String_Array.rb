# words_array = ["hello","what","apple","one","group","must","begin","sentence","keyword"," beginning","loop"]

@wordArray
aFile = File.new("Paragraph.txt","r")
if aFile 
	content = aFile.sysread(aFile.size)
	content =content.downcase 
	content = content.gsub(/[,.;]/,"")
    # puts content
	 @wordArray = content.split
	 # puts @wordArray


else 
   puts "Unable to open file!"

   	end

_less = []
_equals = []
_greater = []
for i in @wordArray do

    if i.length <5
       _less.push(i)
    elsif i.length == 5
           _equals.push(i)

    else 
       _greater.push(i)         
    end


end
print "less than 5 : #{_less}"
puts ""
print "equals to 5 : #{_equals}"
puts ""
print "greater than 5: #{_greater}"
puts ""