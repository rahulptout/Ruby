array << "rahul"
puts array