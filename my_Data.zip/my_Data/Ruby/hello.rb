include hello

class Lord

include Geek
end

class Star
	

extend Geek
end

# object access
Lord.new.geeks

# class access
Star.geeks


