time1 = Time.new
puts "Current time : "+time1.inspect

time2 = Time.now
puts "Current Time : "+time2.inspect

puts time1.year
puts time2.year
puts time2.wday

puts Time.local(2008,07,8)

i=0
j=10
for