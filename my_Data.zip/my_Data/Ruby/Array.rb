array = ["rahul"]
puts array