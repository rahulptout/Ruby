require 'test_helper'

class SiteControllerTest < ActionDispatch::IntegrationTest
  test "should get index--skip-routes" do
    get site_index--skip-routes_url
    assert_response :success
  end

end
