# User = User.create(name : "rahul",occupation : "Code Artist")
user = User.create(name: "David", occupation: "Code Artist")
