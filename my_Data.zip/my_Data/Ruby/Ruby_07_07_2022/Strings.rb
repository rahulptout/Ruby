puts 'escape using "\\"';
puts 'That\'s right';

aray = ["1", "rahul","3.43"];
aray .each do |i| 
	puts i

end 	

hsh = color = {"red" => 4114,"green" => 25442 }
hsh.each do |key,value|
	print key , " is " ,value, "\n"
end	