END {
	puts "this is end statement";
}
puts "hello, Ruby!";

BEGIN {
	puts "begin statement use";
}
