# class Class1 
#     def result_Check(score)

#       puts "Enter your score: "
#       # score = gets
#       # score = 99;
 
#      if score<=35
# 	  puts "you are fail with this score: #{score}"

#      elsif score>=60 and score <=70;
# 	   puts "pass in first class: #{score}"

#      elsif score >=71 and score<=85
# 	   puts "Good socre with first class: #{score}"

#      elsif score>=86 and score<=100
# 	   puts "Excellent socre with first class: #{score}"

#      end

#     end


# end



# class1 =Class1.new
# class1.result_Check(78)



# puts "#{true && false}"
# puts "#{true && true}"

# puts "#{true and false}"	
# puts "#{true and true}"

# x = 1
# if x>=2
# 	puts "x is less than 2"
# 	else 
# 		puts " x is greater than 2"

# end



_age = 21
case _age
	when 0..2
		puts "baby"
	when 3..6
		puts "little child"
	when 7..12
		puts "child"
    when 13..18
    	puts "youth"
    when 19..25
        puts "adult"

    end    	