for i in 1..5 do 
   (1..i).each do |a|

   	print " * " 
   end
   puts

end

