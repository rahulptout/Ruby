i=5
while i>=1
	j=1
	while j<=5
       
		if i<=j
          print "*"	
        else 
           print " "  		
		end
	 j+=1	
	end
	puts ""
    i-=1
end