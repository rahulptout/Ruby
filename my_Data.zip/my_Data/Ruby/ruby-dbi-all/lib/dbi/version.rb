#
# $Id: version.rb,v 1.7 2003/09/07 12:41:09 mneumann Exp $
#

module DBI

VERSION = "0.0.21"

end
