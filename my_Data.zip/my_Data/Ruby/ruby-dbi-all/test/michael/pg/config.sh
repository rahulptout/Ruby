DB=dbitest
USER=michael
PW=michael
TABLE1=names
TABLE2=datatypes
