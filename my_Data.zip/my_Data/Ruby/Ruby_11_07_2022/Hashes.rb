puts "Hash store implementation"

# key = "rahul"
# value = 34
# a =Hash.new("#{key}" : value)

# key = "rahulpal"
# value = 12
# a =Hash.new("#{key}" : value)

# a.each {|key, value| puts  "the value of #{key} is #{value}" }
h = {}


# key = 23
# value = "rahul"
# h << :key "rahul"

# b = "12"
# h[:a] = ""
# h[:a] << "#{b}"

# h[:name] = ""
# h[:name] = "rahul"
value0 = "rahul"
 key0 = 12
h = {"#{value0}" => key0}

value1 = "rahul"
 key1 = 12
h = {"#{value1}" => key1}

h.each {|key, value| puts  "the value of #{key} is #{value}" }


