class Product < ApplicationRecord:: Migrations[6.0]

end

product = Product.new
user.name = "rahul"
user.occupation = "Code"

# class User < ApplicationRecord
#   validates : name, presence:true
# end