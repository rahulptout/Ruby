class HelloController < ApplicationController
end
