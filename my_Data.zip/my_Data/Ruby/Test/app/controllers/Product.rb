class Product < ApplicationController
  

end