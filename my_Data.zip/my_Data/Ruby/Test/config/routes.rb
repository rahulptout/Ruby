Rails.application.routes.draw do
  get "/articles", to: "articles#index"
   resources :articles
  resources :books

  get "/books", to: "books#index"

  # root 'hello#index1' defailt
  get "/hello", to: "hello#index1"  
  get "/articles/:id", to: "articles#show"
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
