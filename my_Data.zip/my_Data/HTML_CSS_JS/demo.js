// const person = {
//     test(){
//        setTimeout(function(){
// console.log(this);
//        },2000);

//     },
// };

// person.test();
export const add =(a,b) => {
    return a+b;
};