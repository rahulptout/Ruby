import  {add} from  "./demo.js";
 const x = 5;
 const y = 7;
 console.log(add(12,34));