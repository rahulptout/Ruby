console.log("Ajax ");
let Primarybtn = document.getElementById("Primary");
Primarybtn.addEventListener('click',buttonClickHandler)
function buttonClickHandler(){
    console.log('you have clicked the Primary')
    const xhr = new XMLHttpRequest();

    xhr.open('GEt', 'https://jsonplaceholder.typicode.com/todos/1',true)
    xhr.onprogress = function(){
        console.log('ON progress');
    }

    xhr.onload = function(){
        if(this.status ==200){
            console.log(this.responseText)
        }else{
            console.error("some error!");
        }
        
    }

    xhr.send();
    
}