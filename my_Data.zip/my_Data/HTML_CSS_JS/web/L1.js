// let string = "Please locate where 'locate' occurs!";
// document.getElementById("demo").innerHTML = string.indexOf("locate");

const cars =  ["1","2","3","4"];
let num1 ="";
for(let x of cars){
   num1+=x +" ";
}
console.log(text);


// function calling
let x = toCelsius(90);
let text = "the temperature is " + x + " Celsius";
let text1= "the temperature is " +toCelsius(90)+" Celsius";
console.log(text);
console.log(text1);
function toCelsius(fahrenheit) {
    return (5/9) * (fahrenheit-32);
    
}

const cars1 = {type : "bus", model : 2020 , color : "red"};
console.log(cars.type);
const {type, model,color} = cars;
console.log(type);
console.log(cars["type"]);

// function myFunction() {
    
//     let carName = "Volvo";
//     console.log(carName);
     
// }
// myFunction();
// console.log(carName); error 

const person = {
   firstName: "rahul",
   lastName : "pal",
   id       : 5566,
   fullName : function() {
     return this.firstName + " " + this.lastName;
   }
 };
 console.log(person.fullName());