

i = "Placements"

# using for loop with the range
for a in 1..5 do
	
puts i

end




# array
arr = ["54", "43", "12", "76"]

# using for loop
for j in arr do
	
puts j

end
