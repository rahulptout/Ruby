$LOAD_PATH << '.'
require "Modules"  # fileName
# moduleName.methodName
PD.palindrome

