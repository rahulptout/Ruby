# while
# $i=0
# $num=5
# while $i<$num do
#      puts("Inside the loop i = #{$i}")
#      $i+=1; 
	
# end

#while modifier 

# $j=0
# $num1=5
# begin
	
# puts("Inside the loop i = #{$j}")
#    $j+=1
	
# end while $j < $num1


# until loop
# $i = 0
# $num = 5

# until $i > $num  do
#    puts("Inside the loop i = #$i" )
#    $i +=1;
# end


# until modifier
# $i = 0
# $num = 5
# begin
#    puts("Inside the loop i = #$i" )
#    $i +=1;
# end until $i > $num


# for loop
# for i in 0..5
# 	puts "value of local variable is #{i}"

# end

# (0..5).each do |i|
# 	puts "value of local variable is #{i}"


# break statement

# for i in 0..5 
#    if i >2 then
#       break

#     end
    
#     puts "value of local variable is #{i}"


# end  



# next key word use
# for i in 0..5
#   if i < 2 then
#      next 


#    end 
#    puts "value of local variable is #{i}"

# end  


# redo statement
# for i in 0..5
#   if i < 2 then
#   	  puts "value of local variable is #{i}"
#      # redo 


#    end 
# end 


# retry statement
begin
	
rescue StandardError => e
	
end