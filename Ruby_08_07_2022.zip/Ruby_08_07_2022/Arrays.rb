# names = Array.new(10) { |i| i=i*2  }
# puts "#{names}"
# names1 = ["1","2","3","4","5"]
# names1.each do |i|
# 	print i
# end



# months = Hash.new("jan" => 01 ,"feb" =>02)
# puts "#{months['jan']}"
# puts "#{months[2]}"


# H = Hash["a" => 100, "b" => 200]
# puts "#{H['a']}"
# puts "#{H['b']}"

# H2 = Hash["jan" =>01, "feb" =>02 ]
# puts "#{H2['jan']}"
# Hash.new { |hash, key| hash[key] =  }s



# days = Hash.new("days")
# days = {1=>"first",2=>"second"}
# keys = days.keys
# puts "#{keys}"
# puts "#{days.empty?}"
# days.[3]="three"



# a = [1,2,3,4,5]
# b = Array.new
# b = a.collect
#  puts b 

# a = [1,2,3,4,5]
# b = Array.new
# b = a.collect
# puts b

