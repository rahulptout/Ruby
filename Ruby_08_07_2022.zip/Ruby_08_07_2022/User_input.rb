puts "Enter a number"
value = gets.chomp.to_i
puts value 